package com.aula;

public enum Tipo {
    ESCRITORIO, TECNOLOGIA, VESTUARIO;
}
